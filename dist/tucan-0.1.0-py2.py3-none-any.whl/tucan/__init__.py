"""TUCAN: molecular identifier and descriptor for all domains of chemistry."""

__version__ = "0.1.0"
