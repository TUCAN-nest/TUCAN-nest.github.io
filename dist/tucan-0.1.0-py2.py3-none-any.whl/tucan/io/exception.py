class MolfileParserException(Exception):
    pass
